package com.kidsia.app

import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale

data class Message(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    private var tts: TextToSpeech? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) tts?.language = Locale.FRENCH
        }

        setContent { KidsIAApp { speak(it) } }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kidsia")
    }

    override fun onDestroy() {
        tts?.shutdown()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KidsIAApp(speak: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    var messages by remember {
        mutableStateOf(listOf(
            Message("Bonjour ! Je suis Kids IA 🤖. Pose-moi une question pour apprendre !", false)
        ))
    }

    fun answer(question: String): String {
        val q = question.lowercase(Locale.getDefault()).trim()
        return when {
            q.contains("bonjour") || q.contains("salut") ->
                "Bonjour ! 😊 Que veux-tu apprendre aujourd'hui ?"
            q.contains("2+2") || q.contains("2 + 2") ->
                "2 + 2 = 4. Bravo ! 🧮"
            q.contains("capitale") && q.contains("france") ->
                "La capitale de la France est Paris. 🇫🇷"
            q.contains("planète") || q.contains("planete") ->
                "La Terre est une planète qui tourne autour du Soleil. 🌍☀️"
            q.contains("animal") ->
                "Les animaux sont des êtres vivants. Le chat, le chien et l'éléphant en sont des exemples. 🐶🐱🐘"
            q.isBlank() ->
                "Écris une question et je vais essayer de t'aider."
            else ->
                "Bonne question ! Je peux t'aider à apprendre les maths, le français, les sciences et la culture générale. 📚"
        }
    }

    MaterialTheme {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("🤖 Kids IA") })
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp)
            ) {
                Text(
                    "Apprendre en s'amusant 🌟",
                    style = MaterialTheme.typography.headlineSmall
                )
                Spacer(Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier.weight(1f).fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messages) { msg ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = if (msg.fromUser)
                                Arrangement.End else Arrangement.Start
                        ) {
                            Card {
                                Text(
                                    msg.text,
                                    modifier = Modifier.padding(12.dp)
                                )
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("Pose ta question...") },
                        singleLine = true
                    )
                    Spacer(Modifier.width(8.dp))
                    Button(onClick = {
                        if (input.isNotBlank()) {
                            val question = input
                            val response = answer(question)
                            messages = messages +
                                    Message(question, true) +
                                    Message(response, false)
                            input = ""
                            speak(response)
                        }
                    }) {
                        Text("OK")
                    }
                }
            }
        }
    }
}
